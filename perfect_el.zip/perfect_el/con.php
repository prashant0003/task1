<?php 

$con=mysqli_connect('localhost','root','','perfect') or die("conntection failed");

?>