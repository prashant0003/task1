-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2022 at 11:04 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perfect`
--

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `eventdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `user_name`, `author`, `image`, `eventdt`) VALUES
(2, 'atijesh', '123', 'OIP.jfif', '2022-08-07 12:00:00'),
(3, 'fashon', 'alok singh', 'OIP.jfif', '2022-08-07 13:18:00'),
(4, 'dinesh', 'autor', 'SIGNP.jpg', '2022-08-07 13:41:00'),
(6, 'prashant singh 123', 'yuyg', 'foodzey-chocken.jpg', '2022-08-08 17:57:00'),
(8, 'rahul', 'singh', '', '2022-08-08 18:26:00'),
(10, 'panakaj`', 'singh', '', '2022-08-08 18:46:00'),
(11, 'wqef', 'wegfdv', '', '0000-00-00 00:00:00'),
(12, 'maa samay', 'alok singh', '', '2022-08-08 23:17:00'),
(13, 'wwds', 'wqdsz', '', '2022-08-04 23:24:00'),
(14, 'prameet', 'alok singh', '', '0000-00-00 00:00:00'),
(15, 'ui7ti', 'ui7tyu', '', '0000-00-00 00:00:00'),
(16, 'prashant', 'alok singh', '', '2022-08-11 13:49:00'),
(17, 'prashant', 'alok singh', '', '0000-00-00 00:00:00'),
(18, '', '', '', '0000-00-00 00:00:00'),
(19, 'prashant', 'alok singh', 'Snapchat-1117496.jpg', '0000-00-00 00:00:00'),
(20, 'atijesh', '', 'Snapchat-17172195.mp4', '0000-00-00 00:00:00'),
(21, '', '', '48644918-businessman-hold-with-folder.webp', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
